/// <reference path="../typings/tsd.d.ts" />
/// <reference path="typings/ngstorage.d.ts" />