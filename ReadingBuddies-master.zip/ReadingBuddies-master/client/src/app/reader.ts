namespace app {
    'use strict';

    export interface IReader {
        id: number;
    }

}
