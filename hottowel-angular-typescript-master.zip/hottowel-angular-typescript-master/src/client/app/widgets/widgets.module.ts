namespace app.widgets {
  'use strict';

  angular.module('app.widgets', []);
}
