namespace blocks.router {
  'use strict';

  angular.module('blocks.router', []);
}
