namespace blocks.exception {
  'use strict';

  angular.module('blocks.exception', ['blocks.logger']);
}
